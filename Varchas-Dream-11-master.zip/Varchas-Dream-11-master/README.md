<a href="https://devlup-labs.github.io"><img src="https://img.shields.io/badge/Developed%20under-Winter%20of%20Code%2C%20DevlUp%20Labs-blue"/></a>

# Varchas-Dream-11
An android app where participants create a team of real players for an upcoming Varchas match and compete with other viewers for big prizes. Your team earns points based on your players' performances in the real-life match, so make sure you make the right choices!

## Features
* Choose your Playing 11 on the go. Maximum 7 from a team. 
* Realtime updates about upcoming matches.
* Store multiple teams for multiple sports.


## Installation
1. Click on the green-colored Code button in the above repository and copy the hyperlink
2. Open Android Studio and go to File > New > Project from Version Control
3. In the Version control choose Git from the drop-down menu
4. Then paste the link you copied in the first step in the URL and choose your Directory
5. Click on the Clone button and you are done

## Credits
* [Gaurav Sen](https://github.com/VortexExpansion)
* [Chinmay Borale](https://github.com/bchinmay-star)
